<?php
	if(!defined("INDEX")) die("---");
?>

<h2 class="sub-header">Data Siswa</h2>

<a href="?tampil=siswa_tambah" class="btn btn-block btn-danger btn-flat">Tambah Siswa</a>


<div class="box-header with-border">
              <h3 class="box-title">Data Siswa / <small>Semua Jurusan</h3>
            </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover table-striped">
                                <thead>
                                    <tr>
                                        <th>NIS</th>
                                        <th>NAMA LENGKAP</th>
                                        <th>TANGGAL LAHIR</th>
                                        <th>JURUSAN</th>
                                        <th>ALAMAT</th>
                                        <th>ANGKATAN</th>
                                        <th>OPTIONS</th>
                                    </tr>
                                </thead>

                               <?php
            $no=1;
            $sql = mysql_query("SELECT * FROM siswa order by id_siswa") or die(mysql_error());
            while($data=mysql_fetch_array($sql)){
        ?>

        <tr>

            <td> <?php echo $data['Nis']; ?> </td>
            <td> <?php echo $data['Nama']; ?> </td>
            <td> <?php echo $data['Tanggal_Lahir']; ?> </td>
            <td> <?php echo $data['Jurusan']; ?> </td>
            <td> <?php echo $data['Alamat']; ?> </td>
            <td> <?php echo $data['Angkatan']; ?> </td>
            <td> 
                <a href="?tampil=siswa_edit&id=<?php echo $data['id_siswa']; ?>" class="btn btn-default btn-sm"> Edit </a>
                <a href="?tampil=siswa_hapus&id=<?php echo $data['id_siswa']; ?>" class="btn btn-warning btn-sm"> Hapus </a>
            </td>
        </tr>

        <?php
                $no++;
            }
        ?>

    </table>
</div>