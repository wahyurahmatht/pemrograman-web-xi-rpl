<?php
    if(!defined("INDEX")) die("---");

    mysql_query("UPDATE siswa SET Nis='$_POST[Nis]', Nama='$_POST[Nama]', Tanggal_Lahir='$_POST[Tanggal_Lahir]'
                WHERE id_siswa='$_POST[id]'") or die(mysql_error());

    echo"Data telah diedit";
    echo"<meta http-equiv='refresh' content='1; url=?tampil=siswa'>";
?>