<?php
	if(!defined("INDEX")) die("---");

	$sql = mysql_query("SELECT * FROM siswa WHERE id_siswa='$_GET[id]'") or die(mysql_error());
	$data  	= mysql_fetch_array($sql);
?>

<h2 class="sub-header">Edit Data Siswa</h2>

<form name="edit" method="post" action="?tampil=siswa_editproses" class="form-horizontal">

	<input type="hidden" name="id" value="<?php echo $data['id_siswa']; ?>">
	<div class="form-group">
	     <label class="label-control col-md-8">Nomor Induk Siswa</label>
	    <div class="col-md-8">
			<input type="text" class="form-control" name="Nis" class="form-control" value="<?php echo $data['Nis']; ?>">
               </div>
	</div>
	<div class="form-group">
	     <label class="label-control col-md-8">Nama Lengkap</label>
                           <div class="col-md-8">
			<input type="text" class="form-control" name="Nama" class="form-control" value="<?php echo $data['Nama']; ?>">
                  </div>
	</div>
	<div class="form-group">
	     <label class="label-control col-md-8">Tanggal Lahir</label>
                         <div class="col-md-8">
			<input type="text" class="form-control" name="Tanggal_Lahir" class="form-control" value="<?php echo $data['Tanggal_Lahir']; ?>">
                 </div>
	</div>
    <div class="form-group">
         <label class="label-control col-md-8">Jurusan</label>
                       <div class="col-md-8">
			<input type="text" class="form-control" name="Jurusan" class="form-control" value="<?php echo $data['Jurusan']; ?>">
                </div>
	</div>
    <div class="form-group">
        <label class="label-control col-md-8">Alamat</label>
                    <div class="col-md-8">
			<input type="text" class="form-control" name="Alamat" class="form-control" value="<?php echo $data['Alamat']; ?>">
                 </div>
	</div>
    <div class="form-group">
         <label class="label-control col-md-8">Angkatan</label>
                <div class="col-md-8">
			<input type="text" class="form-control" name="Angkatan" class="form-control" value="<?php echo $data['Angkatan']; ?>">
                 </div>
	</div>
    
    <div class="form-group">
                  <div class="col-md-8" style="margin-top: 15;">
			<input type="submit" name="edit" value="Edit" class="btn btn-success">
                	</div>
	</div>

</form>
</div>