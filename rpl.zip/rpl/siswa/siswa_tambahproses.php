<?php
	if(!defined("INDEX")) die("---");
	
	mysql_query("INSERT INTO siswa set
			Nis 			= '$_POST[Nis]',
			Nama			= '$_POST[Nama]',
			Tanggal_Lahir	= '$_POST[Tanggal_Lahir]',
			Jurusan			= '$_POST[Jurusan]',
			Alamat			= '$_POST[Alamat]',
			Angkatan		= '$_POST[Angkatan]'
		") or die(mysql_error());
	
	echo"Data telah tersimpan";
	echo"<meta http-equiv='refresh' content='1; url=?tampil=siswa'>";
?>