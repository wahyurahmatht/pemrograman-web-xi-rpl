<?php
    if(!defined("INDEX")) die("---");
?>

<h2 class="sub-header">Tambah Siswa</h2>


                      <div class="col-lg-6" style="margin-left: -15px">

                        <form role="tambah" method="post" action="?tampil=siswa_tambahproses">
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="Nomor Induk Siswa" name="Nis">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Nama Lengkap" name="Nama">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Tanggal Lahir" name="Tanggal_Lahir">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Jurusan" name="Jurusan">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Alamat" name="Alamat">                              
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Angkatan" name="Angkatan">
                            </div>
                            <button type="submit" class="btn btn-default">Simpan</button>
                            <button type="reset" class="btn btn-default">Reset</button>
                      </form>  
                    </div>
    