<ul class="sidebar-menu">
	<li class="header">Menu</li>				
	<li class="active"><a href="dasboard.php"><i class="fa fa-home"></i> <span>Dasboard</span></a></li>
	<li><a href="?tampil=siswa"><i class="fa fa-bar-chart"></i> <span>Data Siswa</span></a></li>

</ul>